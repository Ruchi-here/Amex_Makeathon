# Running the script

1. Install all packages in `./package-list.txt`, preferablly in a conda env.
2. If necessary, run `./bootstrap_db.py` and `./bootstrap_users.py` 
3. Run the `./bootstrap_articles.py` script
4. Run `flask run` to start.

